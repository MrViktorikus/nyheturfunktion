<?php

/* Ger ett schema objekt om paramter PNG inte �r angiven.
 * Annars ger den en addres till en PNG av schemat.
 * Ger �ven PNG om JSON filen inte finns.
 */

/* Parametrar:
  klass = klass ID ex. na12c

  vecka = heltal enligt ISO-8601
  om inget anges s�tts den till nuvarande vecka

  ===== F�LJANDE ENDAST F�R PNG =====

  klass kan vara sal ID ex. t419

  dag
  1=m�ndag 2=tisdag 3=onsdag 4=torsdag 5=fredag (0,6,7 ger hela n�sta vecka)
  om inget anges s�tts den till nuvarande dag

  visahelaveckan
  om angiven visas hela nuvarande vecka

  width = bredden p� bilden i pixlar
  om inget anges s�tts den till 360

  height = h�jden p� bilden i pixlar
  om inget anges s�tts den till 480

 */

//klass = klass ID eller sal ID ex. na12c, t419
if (isset($_GET["klass"])) {
    $klass = filter_input(INPUT_GET, "klass");
}

//Om png �r satt, ges addressen till en png ist�llet f�r json.
$png = false;
if (isset($_GET["png"])) {
    $png = true;
}

//vecka = heltal enligt ISO-8601
//om inget anges s�tts den till nuvarande vecka
if (isset($_GET["vecka"])) {
    $vecka = (int) filter_input(INPUT_GET, "vecka");
} else {
    $vecka = (int) date("W");
}

//1=m�ndag 2=tisdag 3=onsdag 4=torsdag 5=fredag 5.955=alla dagarna
//om inget anges s�tts den till nuvarande dag
if (isset($_GET["dag"])) {
    $dag = filter_input(INPUT_GET, "dag");
} else {
    $dag = date("w");
}

//om visahelaveckan �r satt, visas hela nuvarande vecka.
if (isset($_GET["visahelaveckan"])) {
    $dag = 0;
} elseif ($dag == 0 || $dag == 6 || $dag == 7) { //visa hela n�sta vecka p� helger.
    $vecka++;
    $dag = 0;
}

//width = bredden p� bilden i pixlar
//om inget anges s�tts den till 360
if (isset($_GET["width"])) {
    $width = filter_input(INPUT_GET, "width");
} else {
    $width = 360;
}

//height = h�jden p� bilden i pixlar
//om inget anges s�tts den till 480
if (isset($_GET["height"])) {
    $height = filter_input(INPUT_GET, "height");
} else {
    $height = 480;
}


if (isset($klass)) {
    if ($png) {
        echo 'http://www.novasoftware.se/ImgGen/schedulegenerator.aspx?format=png&schoolid=89920/sv-se&type=1&id=' . $klass . '&period=&week=' . $vecka . '&day=' . (int) pow(2, $dag - 1) . '&width=' . $width . '&height=' . $height;
    } else {
        if (file_exists("save/schemaW" . $vecka . "K_" . $klass . ".json")) {
            echo file_get_contents("save/schemaW" . $vecka . "K_" . $klass . ".json");
        } else {
            echo 'http://www.novasoftware.se/ImgGen/schedulegenerator.aspx?format=png&schoolid=89920/sv-se&type=1&id=' . $klass . '&period=&week=' . $vecka . '&day=' . (int) pow(2, $dag - 1) . '&width=' . $width . '&height=' . $height;
        }
    }
} else {
    echo "klass inte definierad";
}
?>