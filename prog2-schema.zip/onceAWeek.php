<?php

$classesJSON = file_get_contents("http://schema.jeremi.se/api/v1/classes/89920/353973");

$classes = json_decode($classesJSON);

$vecka = (int) date("W");

for ($i = 1; $i < 4; $i++) {
    foreach ($classes as $class) {
        $file = fopen("save/schemaW" . ($vecka+$i) . "K_" . $class . ".json", "w");
        fwrite($file, file_get_contents("http://schema.jeremi.se/api/v1/89920/" . $class . "/" . ($vecka+$i)));
    }
}
echo "done";
?>