<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    
    <style>
        #bild{
            position:relative;
            
        }
        
        #ivtis{
            position:absolute;
            top:33%;
            border:solid thin black;
            height: 100px;
            width: 360px;
            background-color: pink;
        }
        #ivtor{
            position:absolute;
            top:3%;
            border:solid thin black;
            height: 80px;
            width: 360px;
            background-color: pink;
        }
        
    </style>
    
    <body>
        
              
        <?php
        include 'schema.php';
        ?>
    </body>
</html>
