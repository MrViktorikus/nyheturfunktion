S�tt ett par CRON jobb som k�r onceADay.php p� morgonen varje dag, onceAWeek.php p� m�ndag varje vecka (en timme efter den onceADay.php kanske?), onceAYear.php p� slutet av sommarlovet.

save mappen m�ste finnas.