<?php

foreach(glob("save/*.json") as $file){
    unlink($file);
}
echo "done";
?>